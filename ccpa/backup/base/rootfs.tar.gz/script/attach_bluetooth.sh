#!/bin/sh
# Slim IW416 (SDIO 0x9159) Bluetooth attach — owned rewrite.
# Loads hci_uart, the NXP BT firmware over ttymxc2, attaches HCI, sets MAC/HFP/BLE,
# and starts bluetoothDaemon. All non-IW416 chip branches removed.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin:/tmp/bin:$PATH

attach_bt() {
	test -e /tmp/hci_uart.ko && ! grep -q "^hci_uart " /proc/modules && insmod /tmp/hci_uart.ko
	fw_loader_linux /dev/ttymxc2 115200 1 /lib/firmware/nxp/uartiw416_bt_v0.bin 3000000
	hciattach /dev/ttymxc2 any 3000000 flow
	hciconfig hci0 up
	if ! cat /sys/class/bluetooth/hci0/address 2>/dev/null | grep -qi "38:ba:b0"; then
		nxpBTMac=$(set_wifi_mac | sed "s/Setting Wi-Fi MAC address: 00:E0:4C/38:BA:B0/")
		BTMac=$(echo "$nxpBTMac" | awk -F: '{print $6, $5, $4, $3, $2, $1}')
		hcitool -i hci0 cmd 3f 61 00 01 02 1c 37 e0 1c 00 ff ff ff ff 01 8f 08 04 08 00 00 00 c0 c6 2d 00 $BTMac f0 00
		hciconfig hci0 reset
	fi
	hciconfig hci0 scomtu 240:32                    # HFP voice quality
	hcitool -i hci0 cmd 0x3f 0x1d 0x00              # route SCO to HCI
	hcitool -i hci0 cmd 0x3F 0x00EE 0x01 0x02       # BLE power
	hcitool -i hci0 cmd 0x03 0x0003
}

reset_bt() {
	killall hciattach 2>/dev/null
	grep -q "^hci_uart " /proc/modules && { sleep 2; rmmod hci_uart 2>/dev/null; }
	echo 1 > /sys/class/gpio/gpio1/value; sleep 0.1; echo 0 > /sys/class/gpio/gpio1/value
}

cp /usr/sbin/bluetoothDaemon /tmp/bin/ 2>/dev/null
bluetoothDaemon -n &

i=0
while ! ls /tmp/*hci_uart.ko >/dev/null 2>&1 && [ "$i" -lt 120 ]; do i=$((i+1)); sleep 0.1; done

attach_bt
hciconfig hci0 >/dev/null 2>&1; rc=$?
t=0
while [ "$rc" -ne 0 ] && [ "$t" -lt 20 ]; do
	t=$((t+1)); reset_bt; attach_bt; hciconfig hci0 >/dev/null 2>&1; rc=$?
done
[ "$rc" -eq 0 ] && echo "[attach_bluetooth] hci0 up: $(cat /sys/class/bluetooth/hci0/address 2>/dev/null)" \
                || echo "[attach_bluetooth] FAILED after $t retries"
touch /tmp/.hciattach_done
